#!/usr/bin/env python3
# --------------publicador-suscriptor de Point----------------
import rospy
from geometry_msgs.msg import Point
from std_msgs.msg import Int32
from std_msgs.msg import Float64


rospy.init_node('cod3', anonymous=True)	

joint1_value = 0.0
joint2_value = 0.0
joint3_value = 0.0

#se crea la funcion para recibir el mensaje del topico
def callback1(valor):
	global joint1_value
	joint1_value=valor.data
	print("El valor1 es:",joint1_value)

#se crea la funcion para recibir el mensaje del topico
def callback2(data):	
	global joint2_value
	joint2_value=data.data
	print("El valor2 es:",joint2_value)


sub = rospy.Subscriber('random_int', Int32, callback1)
sub = rospy.Subscriber('random_float', Float64, callback2)
pub = rospy.Publisher('random_point', Point, queue_size=10)
rate = rospy.Rate(1) # 1hz --> 1/1hz=1s
while not rospy.is_shutdown():
	xvalor=joint1_value
	yvalor=joint2_value
	zvalor=joint1_value+joint2_value		
	pointmessaje = Point(xvalor, yvalor, zvalor)
	pub.publish(pointmessaje)
	rate.sleep() # delay de 1 segundo