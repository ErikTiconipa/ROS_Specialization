#!/usr/bin/env python3
# --------------publicador-suscriptor de Point----------------
import rospy
from geometry_msgs.msg import Point
from std_msgs.msg import Int32
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist


rospy.init_node('cod2', anonymous=True)	

joint1_value = 0.0
joint2_value = 0.0
joint3_value = 0.0
joint4_value = 0.0
joint5_value = 0.0
joint6_value = 0.0

def callback(data):
	#rospy.loginfo("I heard %d", data.x) #como print
	global joint1_value,joint2_value,joint3_value,joint4_value,joint5_value,joint6_value
	joint1_value = data.linear.x;
	joint2_value = data.linear.y;
	joint3_value = data.linear.z;
	joint4_value = data.angular.x;
	joint5_value = data.angular.y;
	joint6_value = data.angular.z;


sub = rospy.Subscriber("random_twist", Twist, callback)  
pub = rospy.Publisher('random_point_linear', Point, queue_size=10)
pub2 = rospy.Publisher('random_point_angular', Point, queue_size=10)
rate = rospy.Rate(1) # 1hz --> 1/1hz=1s
while not rospy.is_shutdown():
	xvalor=joint1_value
	yvalor=joint2_value
	zvalor=joint3_value		
	pointmessaje = Point(xvalor, yvalor, zvalor)
	pub.publish(pointmessaje)
	xvalor2=joint4_value
	yvalor2=joint5_value
	zvalor2=joint6_value		
	pointmessaje2 = Point(xvalor2, yvalor2, zvalor2)
	pub2.publish(pointmessaje2)
	rate.sleep() # delay de 1 segundo